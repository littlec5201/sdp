package com.development.software.finance;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainAppTest {

	// ERM????????

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
