package com.development.software.finance.view;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import com.development.software.finance.model.Expense;
import com.development.software.finance.util.DateUtil;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;

public class MonthlyExpensesGraphController {
	@FXML
	private BarChart<String, Float> barChart; // line graph more appropriate?

	@FXML
	private CategoryAxis xAxis;

	private ObservableList<String> dates = FXCollections.observableArrayList();

	private ObservableList<LocalDate> datess = FXCollections.observableArrayList();

	// use hashmap to link costs and dates perhaps? no duplicate dates... problem

	/**
	 * Initializes the controller class
	 * This is called after the FXML file has been loaded
	 */
	@FXML
	private void initialize(){
	}

	/**
	 * Sets the expenses to show statistics for
	 * @param expenses
	 */
	public void setExpenseData(List<Expense> expenses){
		for(Expense e: expenses){
			dates.add(DateUtil.format(e.getDate()));
			datess.add(e.getDate());
		}
		Collections.sort(datess); // test these
		Collections.sort(dates); // test these

		// maybe another loop needed after sorting LocalDate list
		// to parse string into String list

		xAxis.setCategories(dates);
	}


}
