package com.development.software.finance.model;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class User {

	private StringProperty userName;
	private FloatProperty savings;


	private ObservableList<Job> jobsData = FXCollections.observableArrayList();
	private ObservableList<Expense> expencesData = FXCollections.observableArrayList();


	public User(){
		this(null, 0.00f);
	}

	public User(String userName, float savings){
		this.userName = new SimpleStringProperty(userName);
		this.savings = new SimpleFloatProperty(savings);
	}

	public ObservableList<Job> getJobsData(){
		return this.jobsData;
	}

	public ObservableList<Expense> getExpencesData(){
		return this.expencesData;
	}

	/**
	 * Sets the savings
	 * will probably remove later due to security
	 */
	public void updateSavings(Float savings){
		this.savings = new SimpleFloatProperty(savings);
	}

	/**
	 * Adds to Savings
	 */
	public void addToSavings(float add){
		this.savings = new SimpleFloatProperty(this.getSavings()+add);
	}

	/**
	 * Removes from Savings
	 */
	public void removeFromSavings(float remove){
		this.savings = new SimpleFloatProperty(this.getSavings()-remove);
	}

	public String getUserName(){
		return userName.get();
	}

	public float getSavings(){
		return savings.get();
	}

	public FloatProperty savingsProperty(){
		return savings;
	}

	public StringProperty getUserNameProperty() {
		return userName;
	}

	public void setUserName(StringProperty userName) {
		this.userName = userName;
	}

	public void setUserNameS(String userName){
		this.userName = new SimpleStringProperty(userName);
	}

}
