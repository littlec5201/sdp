package com.development.software.finance;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.development.software.finance.model.BudgetListWrapper;
import com.development.software.finance.model.Expense;
import com.development.software.finance.model.Job;
import com.development.software.finance.model.User;
import com.development.software.finance.view.ExpenseEditDialogController;
import com.development.software.finance.view.JobEditDialogController;
import com.development.software.finance.view.MonthlyGraphController;
import com.development.software.finance.view.PrintOptionsViewController;
import com.development.software.finance.view.RootLayoutController;
import com.development.software.finance.view.UpdateSavingsController;
import com.development.software.finance.view.UserOverviewController;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainApp extends Stage {

	private Stage primaryStage;
	private BorderPane rootLayout;

	private User user;

	private String username;

	private MonthlyGraphController controller;

	File file;

    public Stage getPrimaryStage(){
		return primaryStage;
	}

	public User getUser(){
		return user;
	}

	public MainApp(String username){
		this.primaryStage = new Stage();
		this.primaryStage.setTitle("Finance App");
		this.username = username;


		// list of initial users for testing
		user = new User(username, 2000);
		user.getExpencesData().add(new Expense("Rent", 400.00f));
		user.getExpencesData().add(new Expense("Power", 200.00f));
		user.getExpencesData().add(new Expense("Water", 100.00f));
		user.getJobsData().add(new Job("Work", 600.00f));
		user.getJobsData().add(new Job("Sugar Daddy", 300.00f));
		user.getJobsData().add(new Job("Bribes", 100.00f));

		initRootLayout();
		showUserOverview();
	}

	public void initRootLayout(){
		try{
			// load layout from fxml file
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
			rootLayout = (BorderPane) loader.load();

			// show scene containing root layout
			Scene scene = new Scene(rootLayout);
			primaryStage.setScene(scene);

			// give controller access to the main app
			RootLayoutController controller = loader.getController();
			controller.setMainApp(this);

			primaryStage.show();
		} catch(IOException e){
			e.printStackTrace();
		}

		file = getBudgetFilePath();
		if(file.length() != 0){
			loadBudgetDataFromFile(file);
		}
	}

	public void showUserOverview(){
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/UserOverview.fxml"));
			AnchorPane userOverview = (AnchorPane) loader.load();

			rootLayout.setCenter(userOverview);

			UserOverviewController controller = loader.getController();
			controller.setMainApp(this);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Opens a dialog to edit details for the specified expense. If the user
	 * clicks OK, the changes are saved into the provided person object and true
	 * is returned.
	 *
	 * @param expense the expense object to be edited
	 * @return true if the user clicked OK, false otherwise.
	 */
	public boolean showExpenseEditDialog(Expense expense){
		try{
			// Load the FXML file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(MainApp.class.getResource("view/ExpenseEditDialog.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();

	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Edit Expense");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the expense into the controller.
	        ExpenseEditDialogController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        controller.setExpense(expense);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();


	        return controller.isOkClicked();
		}catch(IOException e){
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Opens a dialog to edit details for the specified expense. If the user
	 * clicks OK, the changes are saved into the provided person object and true
	 * is returned.
	 *
	 * @param expense the expense object to be edited
	 * @return true if the user clicked OK, false otherwise.
	 */
	public boolean showJobEditDialog(Job job){
		try{
			// Load the FXML file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(MainApp.class.getResource("view/JobEditDialog.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();

	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Edit Job");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the expense into the controller.
	        JobEditDialogController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        controller.setJob(job);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        return controller.isOkClicked();
		}catch(IOException e){
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * This is returns the file preference:
	 * the file that was last opened
	 *
	 */
	public File getBudgetFilePath() {
		String filePath = username+".xml";
	    return new File(filePath);
	}

	/**
	 * Loads the budget data from the specified file. Current expense data will be replaced
	 * @param File
	 */
	public void loadBudgetDataFromFile(File file){
		try{
			JAXBContext context = JAXBContext.newInstance(BudgetListWrapper.class);
			Unmarshaller um = context.createUnmarshaller();

			// Reading XML from file and unmarshalling
			BudgetListWrapper wrapper = (BudgetListWrapper)um.unmarshal(file);

			user.getExpencesData().clear();
			user.getJobsData().clear();

			user.getExpencesData().addAll(wrapper.getExpenses());
			user.getJobsData().addAll(wrapper.getJobs());
			user.setUserNameS(wrapper.getUserName());
			user.updateSavings(wrapper.getSavings());

		}catch(Exception e){
			e.printStackTrace();
			Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText("Could not load data");
	        alert.setContentText("Could not load data from file:\n" + file.getPath());

	        alert.showAndWait();
		}
	}


	/**
	 * Saves the current expense data to the specified file
	 * @param file
	 */
	public void saveBudgetDataToFile(File file){
		try {
	        JAXBContext context = JAXBContext
	                .newInstance(BudgetListWrapper.class);
	        Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

	        // Wrapping our person data.
	        BudgetListWrapper wrapper = new BudgetListWrapper();

	        // changing to single user
	        wrapper.setUserName(user.getUserName());
	        wrapper.setExpenses(user.getExpencesData());
	        wrapper.setJobs(user.getJobsData());
	        wrapper.setSavings(user.getSavings());

	        // Marshalling and saving XML to the file.
	        m.marshal(wrapper, file);

	    } catch (Exception e) {
	    	e.printStackTrace();
	        Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText("Could not save data");
	        alert.setContentText("Could not save data to file:\n" + file.getPath());

	        alert.showAndWait();
	    }
	}

	public void showMonthlyGraph() {
	    try {
	        // Load the fxml file and create a new stage for the popup.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(MainApp.class.getResource("view/MonthlyGraph.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Monthly Graph");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the persons into the controller.
	        MonthlyGraphController controller = loader.getController();
	        controller.setPersonData(user);

	        dialogStage.show();

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	public LineChart getGraph(){
		return controller.getGraph();
	}

	public void showPrintOverview(){
		try {
            /*Loads the PrintOptionsView fxml file*/
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/PrintOptionsView.fxml"));
            AnchorPane PrintOptionsView = (AnchorPane) loader.load();

            Stage printStage = new Stage();
            printStage.setTitle("Print");
            printStage.initOwner(primaryStage);
            Scene scene = new Scene(PrintOptionsView);
            printStage.setScene(scene);

            /*Gives PrintOptionsViewControler access to the main app.*/
            PrintOptionsViewController controller = loader.getController();
            controller.setMainApp(this);
            controller.setUpPrinting(user);

            printStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public Float showUpdateSavingsDialog(Float savings){
		try{
			// Load the FXML file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(MainApp.class.getResource("view/UpdateSavingsDialog.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();

	         //Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Update Savings");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        UpdateSavingsController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        controller.setSavings(user.getSavings());

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        return controller.getSavings();
		}catch(IOException e){
			e.printStackTrace();
			return -1f;
		}
	}
}