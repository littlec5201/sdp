package com.development.software.finance.view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UpdateSavingsController {

	@FXML
	private TextField amount;

	private Stage dialogStage;

	private Float savings;

	/**
	 * Initializes the controller class. This method is automatically called
	 * after the FXML file is called
	 */
	@FXML
	private void initialize(){
	}

	/**
	 * Sets the stage for this dialog
	 */
	public void setDialogStage(Stage dialogStage){
		this.dialogStage = dialogStage;
	}

	/**
	 * Sets the savings value to be added to the dialog
	 */
	public void setSavings(Float savings){
		this.savings = savings;
		amount.setText(Float.toString(savings));
	}

	public Float getSavings(){
		return this.savings;
	}

	/**
	 * called when user clicks updateSavings
	 */
	@FXML
	private void handleUpdate(){
		if(isInputValid()){
			savings = Float.parseFloat(amount.getText());
			dialogStage.close();
		}
	}

	/**
	 * checks for valid user input
	 */
	@FXML
	private boolean isInputValid(){
		String errorMessage = "";

		if(amount.getText() == null || amount.getText().length() == 0){
			errorMessage += "No valid amount!\n";
		}else{
			try{
				Float check = Float.parseFloat(amount.getText());
			}catch(NumberFormatException e){
				errorMessage += "No valid amount (Must be a number)";
			}
		}
		if(errorMessage.length() == 0){
			return true;
		}else{
			// Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid amount entered");
            alert.setHeaderText("Please enter correct amount");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
		}
	}

	/**
	 * called when the user clicks cancel
	 */
	@FXML
    private void handleCancel() {
        dialogStage.close();
    }

}
