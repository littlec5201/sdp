package com.development.software.finance.view;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import com.development.software.finance.MainApp;

import javafx.fxml.FXML;

public class RootLayoutController {

	//Reference to main application
	private MainApp mainApp;

	/**
	 * Is called by the main application to give reference to itself
	 * @param mainApp
	 */
	public void setMainApp(MainApp mainApp){
		this.mainApp = mainApp;
	}


	// check main for getUserFilePath and setFilePath methods
	@FXML
	private void handleSave(){
		File expenseFile = mainApp.getBudgetFilePath();
		mainApp.saveBudgetDataToFile(expenseFile);
	}



	@FXML
	private void handleShowMonthlyGraph() {
	  mainApp.showMonthlyGraph();
	}

	@FXML
	private void handleShowPrintOverview(){
		mainApp.showPrintOverview();
	}

	@FXML
	 private void handleHelp() {
	  File pdfFile = new File("Help.pdf");
	  if (pdfFile.exists()) {

	   if (Desktop.isDesktopSupported()) {
	    try {
	     Desktop.getDesktop().open(pdfFile);
	    } catch (IOException e) {
	     // TODO Auto-generated catch block
	     e.printStackTrace();
	    }
	   }
	  }
	 }

	@FXML
	private void handleExit(){
		System.exit(0);
	}

}
