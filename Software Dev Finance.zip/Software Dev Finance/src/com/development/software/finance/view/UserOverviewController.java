package com.development.software.finance.view;



import java.time.LocalDate;

import com.development.software.finance.MainApp;
import com.development.software.finance.model.Expense;
import com.development.software.finance.model.Job;
import com.development.software.finance.util.DateUtil;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class UserOverviewController {

	@FXML
	private TableView<Job> jobTable;
	@FXML
	private TableColumn<Job, String> jobNameColumn;
	@FXML
	private TableColumn<Job, Float> jobFloatColumn;
	@FXML
	private TableView<Expense> expenseTable;
	@FXML
	private TableColumn<Expense, String> expenseNameColumn;
	@FXML
	private TableColumn<Expense, Float> expenseFloatColumn;

	@FXML
	private Label jobName;
	@FXML
	private Label income;
	@FXML
	private Label jobDate;
	@FXML
	private Label currentDate;

	@FXML
	private Label expenseName;
	@FXML
	private Label expense;
	@FXML
	private Label expenseDate;

	@FXML
	private Label userID;

	@FXML
	private Label savings;

	private MainApp mainApp;

	/**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
	public UserOverviewController(){

	}

	@FXML
	private void initialize(){
		// Initialize the two tables with two columns each (name and price)
		jobNameColumn.setCellValueFactory(cellData -> cellData.getValue().jobnameProperty());
		jobFloatColumn.setCellValueFactory(cellData -> cellData.getValue().jobIncomeProperty().asObject());
		expenseNameColumn.setCellValueFactory(cellData -> cellData.getValue().expensesNameProperty());
		expenseFloatColumn.setCellValueFactory(cellData -> cellData.getValue().expensesCostProperty().asObject());

		showJobDetails(null);
		showExpenseDetails(null);

		// change listeners
		jobTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> showJobDetails(newValue));
		expenseTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> showExpenseDetails(newValue));
	}

	private void showJobDetails(Job job){
		if(job != null){
			jobName.setText(job.getJobName());
			income.setText("$" + job.getJobIncome());
			jobDate.setText(DateUtil.format(job.getDate()));
		}else{
			jobName.setText("");
			income.setText("");
			jobDate.setText("");

		}
	}

	private void showExpenseDetails(Expense expense){
		if(expense != null){
			this.expense.setText("$"+expense.getCost());
			expenseName.setText(expense.getExpenseName());
			expenseDate.setText(DateUtil.format(expense.getDate()));
		}else{
			this.expense.setText("");
			expenseName.setText("");
			expenseDate.setText("");

		}
	}

	/**
     * Is called by the main application to give a reference back to itself.
     * @param mainApp
     */
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        jobTable.setItems(mainApp.getUser().getJobsData());
        expenseTable.setItems(mainApp.getUser().getExpencesData());
        userID.setText(mainApp.getUser().getUserName());
        savings.setText("$"+mainApp.getUser().getSavings());
        currentDate.setText(DateUtil.format(LocalDate.now()));
    }

    @FXML
    private void handleDeleteJob(){
    	int selectedIndex = jobTable.getSelectionModel().getSelectedIndex();
    	if(selectedIndex >=0){
    		// adjust savings
    		mainApp.getUser().removeFromSavings(jobTable.getItems().get(selectedIndex).getJobIncome());
    		savings.setText("$"+mainApp.getUser().getSavings());
    		jobTable.getItems().remove(selectedIndex);
    	}
    	else{
    		 Alert alert = new Alert(AlertType.WARNING);
    	     alert.initOwner(mainApp.getPrimaryStage());
    	     alert.setTitle("No Selection");
    	     alert.setHeaderText("No job Selected");
    	     alert.setContentText("Please select a job in the table.");

    	     alert.showAndWait();
    	}
    }

    @FXML
    private void handleDeleteExpense(){
    	int selectedIndex = expenseTable.getSelectionModel().getSelectedIndex();
    	if(selectedIndex >= 0){
    		mainApp.getUser().addToSavings(expenseTable.getItems().get(selectedIndex).getCost());
    		savings.setText("$"+mainApp.getUser().getSavings());
    		expenseTable.getItems().remove(selectedIndex);
    	}
    	else{
    		 Alert alert = new Alert(AlertType.WARNING);
    	     alert.initOwner(mainApp.getPrimaryStage());
    	     alert.setTitle("No Selection");
    	     alert.setHeaderText("No expense Selected");
    	     alert.setContentText("Please select a expense in the table.");

    	     alert.showAndWait();
    	}
    }

    /**
	 * Called when the user clicks the new expense button. Opens a dialog to edit
	 * details for a new expense.
	 */
	@FXML
	private void handleNewExpense() {
	    Expense tempExpense = new Expense();
	    boolean okClicked = mainApp.showExpenseEditDialog(tempExpense);
	    if (okClicked) {
	    	mainApp.getUser().getExpencesData().add(tempExpense);
	    	/// adjust savings for new expense here!
	    	mainApp.getUser().removeFromSavings(tempExpense.getCost());
	    	savings.setText("$"+mainApp.getUser().getSavings());

	    }
	}

	/**
	 * Called when the user clicks the edit expense button. Opens a dialog to edit
	 * details for the selected expense.
	 */
	@FXML
	private void handleEditExpense() {
	    Expense selectedExpense = expenseTable.getSelectionModel().getSelectedItem();
	    if (selectedExpense != null) {
	    	Float tempCost = selectedExpense.getCost();
	        boolean okClicked = mainApp.showExpenseEditDialog(selectedExpense);
	        if (okClicked) {
	        	mainApp.getUser().addToSavings(tempCost);
	        	mainApp.getUser().removeFromSavings(selectedExpense.getCost());
	        	savings.setText("$"+mainApp.getUser().getSavings());
	            showExpenseDetails(selectedExpense);
	            expenseTable.refresh();
	        }
	    } else {
	        // Nothing selected.
	        Alert alert = new Alert(AlertType.WARNING);
	        alert.initOwner(mainApp.getPrimaryStage());
	        alert.setTitle("No Selection");
	        alert.setHeaderText("No Expense Selected");
	        alert.setContentText("Please select an expense in the table.");

	        alert.showAndWait();
	    }
	}

	/**
	 * Called when the user clicks the new job button. Opens a dialog to edit
	 * details for a new expense.
	 */
	@FXML
	private void handleNewJob() {
	    Job tempJob = new Job();
	    boolean okClicked = mainApp.showJobEditDialog(tempJob);
	    if (okClicked) {
	    	mainApp.getUser().getJobsData().add(tempJob);
	    	// change savings
	    	mainApp.getUser().addToSavings(tempJob.getJobIncome());
	    	savings.setText("$"+mainApp.getUser().getSavings());
	    }
	}

	/**
	 * Called when the user clicks the edit job button. Opens a dialog to edit
	 * details for the selected expense.
	 */
	@FXML
	private void handleEditJob() {
	    Job selectedJob = jobTable.getSelectionModel().getSelectedItem();
	    if (selectedJob != null) {
	    	Float tempJob = selectedJob.getJobIncome();
	        boolean okClicked = mainApp.showJobEditDialog(selectedJob);
	        if (okClicked) {
	        	// edit savings accordingly
	        	mainApp.getUser().removeFromSavings(tempJob);
	        	mainApp.getUser().addToSavings(selectedJob.getJobIncome());
	        	savings.setText("$"+mainApp.getUser().getSavings());
	            showJobDetails(selectedJob);
	            jobTable.refresh();
	        }

	    } else {
	        // Nothing selected.
	        Alert alert = new Alert(AlertType.WARNING);
	        alert.initOwner(mainApp.getPrimaryStage());
	        alert.setTitle("No Selection");
	        alert.setHeaderText("No Job Selected");
	        alert.setContentText("Please select a job in the table.");
	        alert.showAndWait();
	    }
	}


	@FXML
	private void handleUpdateSavings(){
		Float tempSavings = mainApp.showUpdateSavingsDialog(0.00f);
		mainApp.getUser().updateSavings(tempSavings);
		savings.setText("$"+mainApp.getUser().getSavings());
	}
}